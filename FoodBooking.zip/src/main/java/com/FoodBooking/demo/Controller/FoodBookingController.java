package com.FoodBooking.demo.Controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.FoodBooking.demo.Entity.Booking;
import com.FoodBooking.demo.Entity.BookingHistory;
import com.FoodBooking.demo.Entity.Employee;
import com.FoodBooking.demo.Entity.Session;
import com.FoodBooking.demo.Repository.BookingHistoryRepository;
import com.FoodBooking.demo.Repository.BookingRepository;
import com.FoodBooking.demo.Repository.EmployeeRepository;
import com.FoodBooking.demo.Repository.SessionRepository;

import jakarta.persistence.NonUniqueResultException;

@RestController
public class FoodBookingController {

	@Autowired
	SessionRepository sessionRep;
	
	@Autowired
	BookingRepository bookingRep;
	
	@Autowired
	BookingHistoryRepository bookingHistoryRep;
	
	@Autowired
	EmployeeRepository employeeRep;

	@RequestMapping(value = "/foodReservation/{employeeId}/{session}/{mode}/{menuDate}", method = RequestMethod.POST)
	public ResponseEntity<Object> foodReservation(@PathVariable String employeeId,
			@PathVariable String session, @PathVariable boolean mode, @PathVariable LocalDate menuDate) {
		Optional<Session> stype = sessionRep.findBySessionName(session);
		int sessionId = stype.get().getId();	
		
		Employee employee = new Employee();
		Booking booking = new Booking();
		Session ses = new Session();
		BookingHistory history = new BookingHistory();
	try {	
		if (mode == true && bookingRep.findByEmployeeIdAndSessionId(employeeId, sessionId)!=null) {
			employee.setId(employeeId);
			ses.setId(sessionId);
			booking.setEmployee(employee);
			booking.setBookingDate(LocalDateTime.now());
			booking.setCreatedBy(employeeId);
			booking.setCreatedDate(LocalDateTime.now());
			booking.setBookingStatus(true);
			booking.setSession(ses);
			bookingRep.save(booking);
			Optional<Booking> book = bookingRep.findByEmployeeIdAndSessionId(employeeId, sessionId);
			int BookingId = book.get().getId();
			booking.setId(BookingId);
//			history.setBooking(booking);
//			history.setBookingDate(LocalDateTime.now());
//			history.setSession(ses);
//			history.setBookingStatus(true);
//			history.setCreatedDate(LocalDateTime.now());
//			history.setCreatedBy(employeeId);
			BookingHistory historyBook = new BookingHistory(LocalDateTime.now(), mode, LocalDateTime.now(), session, booking, ses);
			bookingHistoryRep.save(historyBook);

			return new ResponseEntity<Object>("Booked successfully", HttpStatus.OK);
		} else {
			Optional<Booking> book = bookingRep.findByEmployeeIdAndSessionId(employeeId, sessionId);
			int BookingId = book.get().getId();
			System.out.println(BookingId);
			if (bookingRep.existsById(BookingId)) {
				Optional<Booking> bookUpdate=bookingRep.findById(BookingId);
				bookUpdate.get().setBookingStatus(mode);
				bookingRep.save(bookUpdate.get());			
			}
			booking.setId(BookingId);
			//history.setBooking(booking);
			//history.setBookingDate(LocalDateTime.now());
			ses.setId(sessionId);
			//history.setSession(ses);
			//history.setBookingStatus(mode);
			//history.setCreatedDate(LocalDateTime.now());
			//history.setCreatedBy(employeeId);		
			BookingHistory historyCancel = new BookingHistory(LocalDateTime.now(), mode, LocalDateTime.now(), session, booking, ses);

			//history.BookingHistory(LocalDateTime.now(), mode, LocalDateTime.now(), session, booking, ses);
			bookingHistoryRep.save(historyCancel);
			return new ResponseEntity<Object>("Cancelled successfully", HttpStatus.OK);
		}
	}
	catch(NoSuchElementException e) {
		return new ResponseEntity<Object>("Cancelled not possible", HttpStatus.BAD_REQUEST);
	}
	catch(NonUniqueResultException e) {
		return new ResponseEntity<Object>("Booking not possible", HttpStatus.BAD_REQUEST);
	}

	}
}
