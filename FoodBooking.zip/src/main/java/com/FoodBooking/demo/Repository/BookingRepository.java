package com.FoodBooking.demo.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FoodBooking.demo.Entity.Booking;

public interface BookingRepository extends JpaRepository<Booking,Integer>{

	
	Optional<Booking> findByEmployeeIdAndSessionId(String EmployeeId,int SessionId);
    
}
