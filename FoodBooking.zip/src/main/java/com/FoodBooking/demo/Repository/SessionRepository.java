package com.FoodBooking.demo.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FoodBooking.demo.Entity.Session;

public interface SessionRepository extends JpaRepository<Session,Integer>{
	Optional<Session> findBySessionName(String SessionName );

}
