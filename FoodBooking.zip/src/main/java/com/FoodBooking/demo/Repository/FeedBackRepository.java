package com.FoodBooking.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FoodBooking.demo.Entity.FeedBack;

public interface FeedBackRepository extends JpaRepository<FeedBack,Integer>{

}
