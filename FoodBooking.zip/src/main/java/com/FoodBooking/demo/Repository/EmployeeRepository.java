package com.FoodBooking.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FoodBooking.demo.Entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,String>
{

	

}
