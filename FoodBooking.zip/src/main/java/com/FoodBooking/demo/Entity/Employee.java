package com.FoodBooking.demo.Entity;

import java.sql.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "EMPLOYEE")
public class Employee {
	@Id
	@Column(name="Id")
	private String id;

	@Column(name="FirstName",nullable = false, length = 100)
	private String firstName;

	@Column(name="LastName",nullable = false, length = 50)
	private String lastName;

	@Column(name="PhoneNumber",nullable = false, length = 13)
	private char phoneNumber;

	@Column(name="EmailId",nullable = false, length = 25)
	private String emailId;

	@Column(name="Address",nullable = false, columnDefinition = "nVarchar(50)")
	private String address;

	@Column(name="IsActive",nullable = false, columnDefinition = "bit default 1 ")
	private boolean isActive;

	@Column(name="CreatedDate",nullable = false)
	private Date createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@ManyToOne(targetEntity = Department.class)
	@JoinColumn(name = "DepartmentId")
	private Department department;

	@OneToMany(targetEntity = Authentication.class, mappedBy = "employee")
	private List<Authentication> authentication;

	@OneToMany(targetEntity = Booking.class, mappedBy = "employee")
	private List<Booking> booking;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(char phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}
