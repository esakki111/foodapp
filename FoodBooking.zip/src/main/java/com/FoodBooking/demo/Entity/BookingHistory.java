package com.FoodBooking.demo.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="BOOKINGHISTORY")
public class BookingHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;

	@Column(name="BookingDate",nullable = false)
	private LocalDateTime bookingDate;

	@Column(name="BookingStatus",nullable = false, columnDefinition = "bit")
	private boolean bookingStatus;

	@Column(name="CreatedDate",nullable = false)
	private LocalDateTime createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@ManyToOne(targetEntity = Booking.class)
	@JoinColumn(name = "BookingId", nullable = false)
	private Booking booking;

	@ManyToOne(targetEntity = Session.class)
	@JoinColumn(name = "SessionId", nullable = false)
	private Session session;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDateTime getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}

	public boolean isBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(boolean bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public   BookingHistory( LocalDateTime bookingDate, boolean bookingStatus, LocalDateTime createdDate,
			String createdBy, Booking booking, Session session) {
		this.bookingDate = bookingDate;
		this.bookingStatus = bookingStatus;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.booking = booking;
		this.session = session;
	}

	public BookingHistory() {
	}
    

	
}
