package com.FoodBooking.demo.Entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="BOOKING")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;

	@Column(name="BookingDate",nullable = false)
	private LocalDateTime bookingDate;

	@Column(name="BookingStatus",nullable = false, columnDefinition = "bit")
	private boolean bookingStatus;

	@Column(name="CreatedDate",nullable = false)
	private LocalDateTime createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@ManyToOne(targetEntity = Employee.class)
	@JoinColumn(name = "EmployeeId", nullable = false)
	private Employee employee;

	@ManyToOne(targetEntity = Session.class)
	@JoinColumn(name = "SessionId", nullable = false)
	private Session session;
	
	@ManyToOne(targetEntity=Menu.class)
	@JoinColumn(name="MenuId",nullable=false)
	private Menu menu;

	@OneToMany(targetEntity = FeedBack.class, mappedBy = "booking")
	private List<FeedBack> feedback;

	@OneToMany(targetEntity = BookingHistory.class, mappedBy = "booking")
	private List<BookingHistory> bookingHistory;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDateTime getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}

	public boolean getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(boolean bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	
		
	}

	


	

