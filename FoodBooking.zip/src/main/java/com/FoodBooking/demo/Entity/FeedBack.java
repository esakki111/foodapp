package com.FoodBooking.demo.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "FEEDBACK")
public class FeedBack {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;

	@Column(name="Feedback",nullable = false, columnDefinition = "nVarchar(100)")
	private String feedback;

	@Column(name="Rating",nullable = false)
	private float rating;

	@Column(name="CreatedDate",nullable = false)
	private LocalDateTime createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@ManyToOne(targetEntity = Booking.class)
	@JoinColumn(name = "BookingId", nullable = false)
	private Booking booking;

	@ManyToOne(targetEntity = Menu.class)
	@JoinColumn(name = "MenuId", nullable = false)
	private Menu menu;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}
