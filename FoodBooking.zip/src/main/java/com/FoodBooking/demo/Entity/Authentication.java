package com.FoodBooking.demo.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="AUTHENTICATION")
public class Authentication {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;

	@Column(name="AuthenticationDate",nullable = false)
	private LocalDateTime authenticationDate;

	@Column(name="Otp",nullable = false, length = 4)
	private int otp;

	@Column(name="Status",nullable = false, columnDefinition = "bit")
	private byte status;

	@Column(name="CreatedDate",nullable = false)
	private LocalDateTime createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@ManyToOne(targetEntity = Employee.class)
	@JoinColumn(name = "EmployeeId", nullable = false)
	private Employee employee;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDateTime getAuthenticationDate() {
		return authenticationDate;
	}

	public void setAuthenticationDate(LocalDateTime authenticationDate) {
		this.authenticationDate = authenticationDate;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public byte getStatus() {
		return status;
	}

	public void setStatus(byte status) {
		this.status = status;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
