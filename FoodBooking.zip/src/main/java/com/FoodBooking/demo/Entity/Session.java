package com.FoodBooking.demo.Entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="SESSION")
public class Session {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;

	@Column(name="SessionName",nullable = false, length = 50)
	private String sessionName;

	@Column(name="CreatedDate",nullable = false)
	private LocalDateTime createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@OneToMany(targetEntity = Booking.class, mappedBy = "session")
	private List<Booking> booking;

	@OneToMany(targetEntity = Menu.class, mappedBy = "session")
	private List<Menu> menu;

	@OneToMany(targetEntity = BookingHistory.class, mappedBy = "session")
	private List<BookingHistory> bookingHistory;

	public int getId() {
		return id;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setId(int id) {
		this.id = id;
	}

}
