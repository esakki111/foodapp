package com.FoodBooking.demo.Entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="MENU")
public class Menu {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;

	@Column(name="MenuDate",nullable = false)
	private LocalDate menuDate;

	@Column(name="MenuList",nullable = false)
	private List<String> menuList;

	@Column(name="CreatedDate",nullable = false)
	private LocalDate createdDate;

	@Column(name="CreatedBy",nullable = false)
	private String createdBy;

	@ManyToOne(targetEntity = Session.class)
	@JoinColumn(name = "SessionId", nullable = false)
	private Session session;

	@OneToMany(targetEntity = FeedBack.class, mappedBy = "menu")
	private List<FeedBack> feedback;  

	@OneToMany(targetEntity = Upload.class, mappedBy = "menu")
	private List<Upload> upload;
	
	@OneToMany(targetEntity=Booking.class, mappedBy="menu")
	private List<Booking> booking;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getMenuDate() {
		return menuDate;
	}

	public void setMenuDate(LocalDate menuDate) {
		this.menuDate = menuDate;
	}

	public List<String> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<String> menuList) {
		this.menuList = menuList;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}
