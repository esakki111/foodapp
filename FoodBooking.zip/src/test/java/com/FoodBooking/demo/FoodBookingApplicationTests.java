package com.FoodBooking.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
