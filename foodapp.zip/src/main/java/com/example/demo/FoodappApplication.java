package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.config.twilioConfig;
import com.twilio.Twilio;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class FoodappApplication {
	
	@Autowired
	private twilioConfig twilioconfig;
	
	@PostConstruct
	public void initTwilio() {
		Twilio.init(twilioConfig.accountSid, twilioConfig.authToken);
		
	}

	public static void main(String[] args) {
		SpringApplication.run(FoodappApplication.class, args);
	}

}
