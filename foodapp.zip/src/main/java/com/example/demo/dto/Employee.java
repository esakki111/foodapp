package com.example.demo.dto;


import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	private String employeeId;
	
	@Column(nullable=false,length=20)
	private String firstName;
	
	@Column(nullable=false,length=15)
	private String lastName;
	
	@Column(nullable=false,length=13)
	private String phoneNo;
	
	@Column(nullable=false,length=40)
	private String emailId;
	
	@Column(insertable=false, updatable=false)
	private int departmentId;
	
	@Column(nullable=false,length=50)
	private String address;
	
    @Column(columnDefinition = "bit default 1",nullable = false)
    private byte isActive;
	
	public byte getIsActive() {
		return isActive;
	}

	public void setIsActive(byte isActive) {
		this.isActive = isActive;
	}
	
	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	@ManyToOne
    @JoinColumn(name="departmentId_fk", nullable=false)
    private Department department;
	
    @OneToMany(mappedBy="employee")
    private Set<Authentication> authentication;
    
    @OneToMany(mappedBy="employee")
    private Set<Booking> booking;

	
}
