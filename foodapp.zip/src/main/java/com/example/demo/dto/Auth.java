package com.example.demo.dto;

import java.io.Serializable;

public class Auth implements Serializable{
    private static final long serialVersionUID = 1L;
	private String otp;
    private String phoneNo;    
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

}
