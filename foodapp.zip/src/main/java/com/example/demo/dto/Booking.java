package com.example.demo.dto;

import org.joda.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Booking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private LocalDateTime bookingDate;
	private String sessionId;
	
	@Column(columnDefinition = "bit",nullable = false)
    private byte bookingStatus;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDateTime getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public byte getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(byte bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	@ManyToOne
    @JoinColumn(name="employeeId_fk", nullable=false)
    private Employee employee;

}
