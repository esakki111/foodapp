
package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.joda.time.LocalDate;
import org.joda.time.LocalTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Auth;
import com.example.demo.dto.Authentication;
import com.example.demo.dto.Employee;
import com.example.demo.repository.AuthRepository;
import com.example.demo.repository.EmpRepository;
import com.example.demo.service.TwilioOTPService;

@RestController
@RequestMapping(value = "otp/")
public class OTPController {
	
	 @Autowired
	 private TwilioOTPService otpService;
	
	 @Autowired
	 private EmpRepository emp;
	 
	 @Autowired
	 private AuthRepository authen;

     
	 
	 @RequestMapping(value = "requestOtp/{phoneNo}",method = RequestMethod.GET)
	 public ResponseEntity<String> getOtp(@PathVariable String phoneNo){
	        Map<String,Object> returnMap=new HashMap<>();
	       // Employee emp1 = new Employee();
	        Authentication auth = new Authentication();
	        Employee employee=new Employee();
	        if(emp.existsById(emp.findbyPnoneno(phoneNo))) {
	        try{
	            //generate OTP
	            String otp = otpService.generateOtp(phoneNo);
	            //returnMap.put("otp", otp);
	           // returnMap.put("status","success");
	           // returnMap.put("message","Otp sent successfully");
	            employee.setEmployeeId(emp.findbyPnoneno(phoneNo));
	            System.out.println(emp.findbyPnoneno(phoneNo));
	            auth.setEmployee(employee);
	            auth.setDate(LocalDate.now());
	            auth.setTime(LocalTime.now());
	            auth.setOtp(otp);
	            auth.setStatus((byte) '1');
	            authen.save(auth);
		        return new ResponseEntity<>("Success",HttpStatus.OK);

	        }catch (Exception e){
	            returnMap.put("status","failed");
	            returnMap.put("message",e.getMessage());
	            return new ResponseEntity<>("Failed",HttpStatus.BAD_REQUEST);
        }

	    }
	        else {
	            return new ResponseEntity<>("PhoneNo not registered",HttpStatus.BAD_REQUEST);

	        }
	 }
	 
	 
	    @RequestMapping(value = "verifyOtp/",method = RequestMethod.POST)
	    public ResponseEntity<String> verifyOtp(@RequestBody Auth authenticationRequest){
	        Map<String,Object> returnMap=new HashMap<>();
	        try{
	            //verify otp
	        	System.out.println(authenticationRequest.getOtp());
	        	System.out.println(authenticationRequest.getPhoneNo());
	            if(authenticationRequest.getOtp().equals(otpService.getCacheOtp(authenticationRequest.getPhoneNo()))){
	                returnMap.put("status","success");
	                returnMap.put("message","Otp verified successfully");
	                otpService.clearOtp(authenticationRequest.getPhoneNo());
			        return new ResponseEntity<>("otp verified successfully",HttpStatus.OK);

	                
	            }else{
	                returnMap.put("status","success");
	                returnMap.put("message","Otp is either expired or incorrect");
			        return new ResponseEntity<>("otp is either expired or incorrect ",HttpStatus.BAD_REQUEST);

	            }

	        } catch (Exception e){
	            returnMap.put("status","failed");
	            returnMap.put("message",e.getMessage());
		        return new ResponseEntity<>("failed ",HttpStatus.BAD_REQUEST);

	        }

	    }


}
