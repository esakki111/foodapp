package com.example.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;


@Configuration
@ConfigurationProperties(prefix="twilio")

public class twilioConfig {
	
	public static String accountSid="AC1229ff2281ee5d6655df8ddb50c0e153";
    public static String authToken="ebdeb75dd210edda850f63338e9f168b";
    public static String trialNumber="+15076876967";
    }
